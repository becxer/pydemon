from distutils.core import setup

print 'Thank you for install this tool'

setup(
	name='pydemon',
	version='0.0.2',
	py_modules=['pydemon'],
	author ='becxer',
	author_email='becxer87@gmail.com',
	url = 'https://github.com/becxer/pydemon',
	description = 'Monitor for any changes in your Project',
	license='MIT',
	classifiers=[
		'Development Status :: 3 - Alpha',
		'Topic :: Software Development :: Build Tools',
		'License :: OSI Approved :: MIT License',
		'Programming Language :: Python :: 2.7',
	],
)


	
